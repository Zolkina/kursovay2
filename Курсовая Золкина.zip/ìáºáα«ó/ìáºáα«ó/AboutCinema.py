import sys
from PyQt6.QtWidgets import QApplication, QMainWindow, QLabel, QPushButton
from PyQt6.QtGui import QFont, QColor, QPixmap, QPalette
from PyQt6.QtCore import Qt
import MainPage

class AboutCinema(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("О Кинотеатре")
        self.setGeometry(500, 100, 800, 600)
        palette = QPalette()
        palette.setColor(QPalette.ColorRole.Window, QColor(141, 24, 27))
        self.setPalette(palette)

        self.initUI()

    def open_new_window(self):
        self.new_window = MainPage.CinemaApp()
        self.new_window.show()
        self.hide()

    def initUI(self):
        font = QFont("Century Gothic", 8)
        font1 =QFont("Century Gothic", 20)

        main_label = QLabel(self)
        main_label.setText("О Кинотеатре")
        main_label.setFont(font1)
        main_label.setStyleSheet("color: #f0b967;")
        main_label.setGeometry(300, 20, 200, 30)

        label1 = QLabel(self)
        label1.setText(
            "Изогнутые экраны\nс мини-перфорацией,\nобеспечивающие максимально\nчеткое и равномерное\nизображение без каких-либо\nвизуальных помех даже\nв первом ряду.")
        label1.setAlignment(Qt.AlignmentFlag.AlignCenter)
        label1.setFont(font)
        label1.setStyleSheet("color: #f0b967;")
        label1.setGeometry(50, 125, 200, 200)

        pixmap1 = QPixmap("1.png")
        label_image1 = QLabel(self)
        label_image1.setPixmap(pixmap1)
        label_image1.setGeometry(122, 120, 50, 50)

        label2 = QLabel(self)
        label2.setText(
            "В десяти залах установлены\nудобные кресла-реклайнеры\nс регулируемыми спинкой\nи подставкой для ног,\nаналогичные тем, что\nустановлены в\nбизнес-классе самолетов.")
        label2.setAlignment(Qt.AlignmentFlag.AlignCenter)
        label2.setFont(font)
        label2.setStyleSheet("color: #f0b967;")
        label2.setGeometry(313, 125, 200, 200)

        pixmap2 = QPixmap("2.png")
        pixmap2 = pixmap2.scaled(50, 50)
        label_image2 = QLabel(self)
        label_image2.setPixmap(pixmap2)
        label_image2.setGeometry(385, 120, 50, 50)

        label3 = QLabel(self)
        label3.setText("В семи приватных залах\nгостей обволакивают\n комфортом стильные\n кожаные диваны.")
        label3.setAlignment(Qt.AlignmentFlag.AlignCenter)
        label3.setFont(font)
        label3.setStyleSheet("color: #f0b967;")
        label3.setGeometry(560, 110, 200, 200)

        pixmap3 = QPixmap("3.png")
        pixmap3 = pixmap3.scaled(60, 60)
        label_image3 = QLabel(self)
        label_image3.setPixmap(pixmap3)
        label_image3.setGeometry(630, 120, 60, 60)

        label4 = QLabel(self)
        label4.setText("В кинозалах использованы\nпоглощающие звуки\nтекстильные панели на\nстенах и ковролин с\nвысоким ворсом, что\nсоздает максимальный\nкомфорт и шумоизоляцию.")
        label4.setAlignment(Qt.AlignmentFlag.AlignCenter)
        label4.setFont(font)
        label4.setStyleSheet("color: #f0b967;")
        label4.setGeometry(50, 350, 200, 200)

        pixmap4 = QPixmap("4.png")
        pixmap4 = pixmap4.scaled(50, 50)
        label_image4 = QLabel(self)
        label_image4.setPixmap(pixmap4)
        label_image4.setGeometry(122, 340, 50, 50)

        label5 = QLabel(self)
        label5.setText("Сабвуферы с увеличенными\nдиффузорами, обеспечивающие\nоспроизведение низких\nчастот вплоть\nдо 20 Гц.")
        label5.setAlignment(Qt.AlignmentFlag.AlignCenter)
        label5.setFont(font)
        label5.setStyleSheet("color: #f0b967;")
        label5.setGeometry(313, 340, 200, 200)

        pixmap5 = QPixmap("5.png")
        pixmap5 = pixmap5.scaled(50, 50)
        label_image5 = QLabel(self)
        label_image5.setPixmap(pixmap5)
        label_image5.setGeometry(385, 340, 50, 50)

        label6 = QLabel(self)
        label6.setText("Коаксиальная акустика,\nсоздающая идеальную\n«навигацию» для 3D звука.")
        label6.setAlignment(Qt.AlignmentFlag.AlignCenter)
        label6.setFont(font)
        label6.setStyleSheet("color: #f0b967;")
        label6.setGeometry(560, 325, 200, 200)

        pixmap6 = QPixmap("6.png")
        pixmap6 = pixmap6.scaled(60, 60)
        label_image6 = QLabel(self)
        label_image6.setPixmap(pixmap6)
        label_image6.setGeometry(630, 340, 60, 60)

        back_button = QPushButton("Назад", self)
        button_style = "QPushButton {" \
                       "font-family: Century Gothic;" \
                       "font-size: 10px;" \
                       "color: #f0b967;" \
                       "background-color: #8e0c02;" \
                       "border: 2px solid black;" \
                       "}"
        back_button.setStyleSheet(button_style)
        back_button.clicked.connect(self.open_new_window)
        back_button.setGeometry(0, 555, 100, 35)

if __name__ == '__main__':
    app = QApplication(sys.argv)
    mainWindow = AboutCinema()
    mainWindow.show()
    sys.exit(app.exec())