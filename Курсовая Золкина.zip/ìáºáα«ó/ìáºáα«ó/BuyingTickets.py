import sys
from PyQt6.QtWidgets import QApplication, QMainWindow, QLabel, QVBoxLayout, QWidget, QLineEdit, QPushButton, QComboBox
from PyQt6.QtGui import QFont, QColor, QPalette
import sqlite3
import MainPage
import qrcode
from docx import Document

class TicketPurchaseWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Бронирование билета")
        self.setMinimumWidth(450)
        palette = QPalette()
        palette.setColor(QPalette.ColorRole.Window, QColor(141, 24, 27))
        self.setPalette(palette)

        font = QFont("Century Gothic", 9)
        font1 = QFont("Century Gothic", 16)

        # Создание элементов интерфейса
        self.movie_label = QLabel("Выберите фильм:")
        self.movie_label.setFont(font)
        self.movie_label.setStyleSheet("color: #f0b967;")
        self.movie_combobox = QComboBox(self)
        self.movie_combobox.currentIndexChanged.connect(self.update_session_combobox)

        self.session_label = QLabel("Выберите сеанс:")
        self.session_label.setFont(font)
        self.session_label.setStyleSheet("color: #f0b967;")
        self.session_combobox = QComboBox(self)

        self.price_label = QLabel("Цена за сеанс:")
        self.price_label.setFont(font)
        self.price_label.setStyleSheet("color: #f0b967;")
        self.price_value_label = QLabel()
        self.price_value_label.setFont(font1)
        self.price_value_label.setStyleSheet("color: #f0b967;")

        self.name_label = QLabel("ФИО:")
        self.name_label.setFont(font)
        self.name_label.setStyleSheet("color: #f0b967;")
        self.name_edit = QLineEdit(self)

        self.email_label = QLabel("Email:")
        self.email_label.setFont(font)
        self.email_label.setStyleSheet("color: #f0b967;")
        self.email_edit = QLineEdit(self)

        self.book_button = QPushButton("Забронировать", self)
        self.book_button.clicked.connect(self.book_ticket)
        button_style = "QPushButton {" \
                       "font-family: Century Gothic;" \
                       "font-size: 12px;" \
                       "background-color: #e4d4bb;" \
                       "color: #5a1613;" \
                       "border: 2px solid black;" \
                       "}"
        self.book_button.setStyleSheet(button_style)

        self.back_button = QPushButton("Назад", self)
        self.back_button.clicked.connect(self.open_new_window)
        button_style = "QPushButton {" \
                       "font-family: Century Gothic;" \
                       "font-size: 10px;" \
                       "color: #f0b967;" \
                       "background-color: #8e0c02;" \
                       "border: 2px solid black;" \
                       "}"
        self.back_button.setStyleSheet(button_style)

        # Создание и настройка компоновщика
        layout = QVBoxLayout()
        layout.addWidget(self.movie_label)
        layout.addWidget(self.movie_combobox)
        layout.addWidget(self.session_label)
        layout.addWidget(self.session_combobox)
        layout.addWidget(self.price_label)
        layout.addWidget(self.price_value_label)
        layout.addWidget(self.name_label)
        layout.addWidget(self.name_edit)
        layout.addWidget(self.email_label)
        layout.addWidget(self.email_edit)
        layout.addWidget(self.book_button)
        layout.addWidget(self.back_button)

        # Создание главного виджета и установка компоновщика
        central_widget = QWidget(self)
        central_widget.setLayout(layout)
        self.setCentralWidget(central_widget)

        # Инициализация базы данных
        self.conn = sqlite3.connect('myDB.db')

        # Заполнение комбобокса с фильмами
        self.populate_movie_combobox()

    def populate_movie_combobox(self):
        cursor = self.conn.cursor()
        cursor.execute("SELECT title FROM Films")
        movies = cursor.fetchall()
        self.movie_combobox.clear()
        self.movie_combobox.addItems([movie[0] for movie in movies])
        self.update_session_combobox()

    def update_session_combobox(self):
        selected_movie = self.movie_combobox.currentText()
        cursor = self.conn.cursor()
        cursor.execute(
            "SELECT start_datetime, price FROM Sessions JOIN Films ON Sessions.film_id = Films.id WHERE Films.title = ?",
            (selected_movie,))
        sessions = cursor.fetchall()
        self.session_combobox.clear()
        self.session_combobox.addItems([session[0] for session in sessions])
        self.update_price_label()

    def update_price_label(self):
        selected_session = self.session_combobox.currentText()
        cursor = self.conn.cursor()
        cursor.execute("SELECT price FROM Sessions WHERE start_datetime = ?", (selected_session,))
        price = cursor.fetchone()[0]
        self.price_value_label.setText(f"{price} руб.")

    def book_ticket(self):
        # Получение выбранных значений из комбобоксов
        selected_movie = self.movie_combobox.currentText()
        selected_session = self.session_combobox.currentText()
        name = self.name_edit.text()
        email = self.email_edit.text()

        # Получение цены
        cursor = self.conn.cursor()
        cursor.execute("SELECT price FROM Sessions WHERE start_datetime = ?", (selected_session,))
        price = cursor.fetchone()[0]

        # Добавление данных в базу данных
        cursor.execute("INSERT INTO Bookings (session_id, client_name, num_of_seats, email) VALUES (?, ?, ?, ?)",
                       (selected_session, name, 0, email))
        self.conn.commit()

        # Создание текста для документа
        text = f"Фильм: {selected_movie}\n"
        text += f"Дата и время сеанса: {selected_session}\n"
        text += f"Цена: {price} руб.\n"

        # Генерация QR-кода
        qr_data = f"{selected_movie}, {selected_session}, {price}"
        qr_code = qrcode.make(qr_data)

        # Сохранение QR-кода в файл
        qr_code_path = "qr_code.png"
        qr_code.save(qr_code_path)

        # Создание документа Word и добавление текста и QR-кода
        document = Document()
        document.add_paragraph(text)
        document.add_picture(qr_code_path)
        document.add_paragraph(
            f"{name}, ваш билет забронирован. Для его получения предъявите QR-код на кассе и оплатите. Будем вас ждать!")

        # Сохранение документа
        document_path = "ticket.docx"
        document.save(document_path)

        # Вывод сообщения об успешном бронировании
        print("Билет забронирован. QR-код и информация сохранены в документе ticket.docx")


    def open_new_window(self):
        self.new_window = MainPage.CinemaApp()
        self.new_window.show()
        self.hide()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = TicketPurchaseWindow()
    window.show()
    sys.exit(app.exec())