import sys
from PyQt6.QtWidgets import QApplication, QMainWindow, QLabel, QVBoxLayout, QWidget, QLineEdit, QPushButton, QMessageBox
from PyQt6.QtGui import QPalette, QColor
import Admin
import MainPage

class Autorization(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Авторизация")
        self.setMinimumWidth(300)
        palette = QPalette()
        palette.setColor(QPalette.ColorRole.Window, QColor(228, 212, 187))
        self.setPalette(palette)

        # Создание элементов интерфейса
        self.key_label = QLabel("Ключ администратора:")
        self.key_edit = QLineEdit(self)

        self.login_button = QPushButton("Войти", self)
        self.login_button.clicked.connect(self.login)

        # Создание и настройка компоновщика
        layout = QVBoxLayout()
        layout.addWidget(self.key_label)
        layout.addWidget(self.key_edit)
        layout.addWidget(self.login_button)

        # Создание главного виджета и установка компоновщика
        central_widget = QWidget(self)
        central_widget.setLayout(layout)
        self.setCentralWidget(central_widget)

    def login(self):
        admin_key = "admin123"  # Здесь можно установить корректный ключ администратора

        # Получение введенного ключа
        entered_key = self.key_edit.text()

        if entered_key == admin_key:
            self.open_main_window()
        else:
            self.show_error_message("Неверный ключ.")

    def open_main_window(self):
        self.new_window = Admin.Admin()
        self.new_window.show()
        self.hide()

    def show_error_message(self, message):
        QMessageBox.critical(self, "Ошибка", message)
        self.new_window = MainPage.CinemaApp()
        self.new_window.show()
        self.hide()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    mainWindow = Autorization()
    mainWindow.show()
    sys.exit(app.exec())