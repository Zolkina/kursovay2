from PyQt6.QtWidgets import QApplication, QMainWindow, QTableWidget, QTableWidgetItem, QDialog, QLabel, QVBoxLayout, QPushButton, QMessageBox
from PyQt6.QtGui import QFont, QColor, QPalette
import sqlite3

import MainPage


class MoviePoster(QMainWindow):
    def __init__(self):
        super().__init__()

        # Установка заголовка окна
        self.setWindowTitle("Киноафиша")
        self.setGeometry(500, 100, 600, 400)
        palette = QPalette()
        palette.setColor(QPalette.ColorRole.Window, QColor(228, 212, 187))
        self.setPalette(palette)

        # Установка шрифта
        font = QFont("Century Gothic")
        self.setFont(font)

        # Установка цвета текста
        palette = self.palette()
        palette.setColor(QPalette.ColorRole.Text, QColor("#f0b967"))
        self.setPalette(palette)

        # Создание виджета с таблицей
        self.table_widget = QTableWidget()
        self.setCentralWidget(self.table_widget)

        # Стиль для таблицы
        style = "::section { background-color: #f0b967; color: white; font-weight: bold; }"
        self.table_widget.horizontalHeader().setStyleSheet(style)
        self.table_widget.verticalHeader().setStyleSheet(style)

        self.table_widget.setStyleSheet(
            "QTableWidget { background-image: url('23.jpg'); background-repeat: no-repeat; background-position: center; }")

        # Шрифт для таблицы
        font = QFont("Century Gothic")
        self.table_widget.setFont(font)

        # Загрузка данных из БД
        self.load_data()

    def load_data(self):
        # Подключение к БД
        conn = sqlite3.connect('myDB.db')
        cursor = conn.cursor()

        # Запрос на получение данных сеансов
        cursor.execute('''SELECT Films.title, Sessions.start_datetime, Cinemas.name, Sessions.price
                        FROM Sessions
                        INNER JOIN Films ON Sessions.film_id = Films.id
                        INNER JOIN Cinemas ON Sessions.cinema_id = Cinemas.id
                        ORDER BY Sessions.start_datetime''')
        sessions = cursor.fetchall()

        # Определение количества строк и столбцов таблицы
        row_count = len(sessions)
        column_count = len(sessions[0]) if row_count > 0 else 0

        # Установка размера таблицы
        self.table_widget.setRowCount(row_count)
        self.table_widget.setColumnCount(column_count)

        # Заполнение таблицы данными
        for row in range(row_count):
            for column in range(column_count):
                item = QTableWidgetItem(str(sessions[row][column]))
                self.table_widget.setItem(row, column, item)

        # Установка заголовков столбцов
        self.table_widget.setHorizontalHeaderLabels(["Фильм", "Дата и время", "Кинозал", "Цена"])

        # Отключение возможности редактирования ячеек
        self.table_widget.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)

        # Установка растягивающегося размера столбцов по содержимому
        self.table_widget.resizeColumnsToContents()

        # Закрытие соединения с БД
        conn.close()

        # Привязка функции обработчика события щелчка по ячейкам таблицы
        self.table_widget.cellClicked.connect(self.show_movie_info)

        # Кнопка "Назад"
        back_button = QPushButton("Назад", self)
        button_style = "QPushButton { font-family: Century Gothic; font-size: 12px; background-color: #e4d4bb; color: #5a1613; border: 2px solid black; }"
        back_button.setStyleSheet(button_style)
        back_button.clicked.connect(self.open_new_window)
        back_button.setGeometry(0, 360, 100, 35)

    def show_movie_info(self, row):
        # Получение выбранной ячейки и значения названия фильма
        item = self.table_widget.item(row, 0)
        movie_title = item.text()

        # Подключение к БД
        conn = sqlite3.connect('myDB.db')
        cursor = conn.cursor()

        # Запрос на получение информации о фильме по его названию
        cursor.execute('''SELECT * FROM Films WHERE title = ?''', (movie_title,))
        movie_info = cursor.fetchone()

        # Закрытие соединения с БД
        conn.close()

        if movie_info is not None:
            info_dialog = QDialog(self)
            info_dialog.setWindowTitle("Информация о фильме")
            palette = QPalette()
            palette.setColor(QPalette.ColorRole.Window, QColor(228, 212, 187))
            self.setPalette(palette)
            self.setPalette(palette)

            styleLabel = ("QLabel {"
                          "font-family: Century Gothic;"
                          "font-size: 12px;"
                          "color: #5a1613;"
                          "}")

            layout = QVBoxLayout()
            info_dialog.setLayout(layout)

            title_label = QLabel("Название: " + movie_info[1])
            director_label = QLabel("Режиссер: " + movie_info[2])
            genre_label = QLabel("Жанр:" + str(movie_info[3]))
            age_limit_label = QLabel("Возрастное ограничение: " + str(movie_info[4]))
            duration_label = QLabel("Продолжительность: " + str(movie_info[5]))
            release_year_label = QLabel("Год выпуска: " + str(movie_info[6]))

            title_label.setStyleSheet(styleLabel)
            director_label.setStyleSheet(styleLabel)
            duration_label.setStyleSheet(styleLabel)
            genre_label.setStyleSheet(styleLabel)
            age_limit_label.setStyleSheet(styleLabel)
            release_year_label.setStyleSheet(styleLabel)

            layout.addWidget(title_label)
            layout.addWidget(director_label)
            layout.addWidget(genre_label)
            layout.addWidget(age_limit_label)
            layout.addWidget(duration_label)
            layout.addWidget(release_year_label)

            self.setLayout(layout)

            info_dialog.exec()
        else:
            QMessageBox.warning(self, "Ошибка", "Фильм не найден в базе данных.")

    def open_new_window(self):
        self.new_window = MainPage.CinemaApp()
        self.new_window.show()
        self.hide()


if __name__ == "__main__":
    app = QApplication([])
    window = MoviePoster()
    window.show()
    app.exec()