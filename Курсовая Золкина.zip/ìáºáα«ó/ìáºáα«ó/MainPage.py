import sys
from PyQt6.QtWidgets import QApplication, QMainWindow, QPushButton, QLabel
from PyQt6.QtGui import QPixmap, QPalette, QColor
import AboutCinema
import Autorization
import MoviePoster
import BuyingTickets
import Discounts
import CafeMenu

class CinemaApp(QMainWindow):
    def open_new_window1(self):
        self.new_window = AboutCinema.AboutCinema()
        self.new_window.show()
        self.hide()

    def open_new_window2(self):
        self.new_window = MoviePoster.MoviePoster()
        self.new_window.show()
        self.hide()

    def open_new_window3(self):
        self.new_window = BuyingTickets.TicketPurchaseWindow()
        self.new_window.show()
        self.hide()

    def open_new_window4(self):
        self.new_window = Discounts.Discount()
        self.new_window.show()
        self.hide()

    def open_new_window5(self):
        self.new_window = CafeMenu.CafeMenu()
        self.new_window.show()
        self.hide()

    def open_new_window6(self):
        self.new_window = Autorization.Autorization()
        self.new_window.show()
        self.hide()

    def __init__(self):
        super().__init__()

        # Установка основных параметров окна
        self.setWindowTitle("Кинотеатр")
        self.setGeometry(500, 100, 800, 600)
        palette = QPalette()
        palette.setColor(QPalette.ColorRole.Window, QColor(90, 22, 19))
        self.setPalette(palette)

        # Создание кнопок
        button1 = QPushButton("О кинотеатрах", self)
        button1.clicked.connect(self.open_new_window1)
        button2 = QPushButton("Киноафиша", self)
        button2.clicked.connect(self.open_new_window2)
        button3 = QPushButton("Покупка билетов", self)
        button3.clicked.connect(self.open_new_window3)
        button4 = QPushButton("Скидки", self)
        button4.clicked.connect(self.open_new_window4)
        button5 = QPushButton("Меню Кафе", self)
        button5.clicked.connect(self.open_new_window5)
        button6 = QPushButton("Кнопка Админа", self)
        button6.clicked.connect(self.open_new_window6)

        # Установка стилей кнопок
        button_style = "QPushButton {" \
                       "font-family: Century Gothic;" \
                       "font-size: 18px;" \
                       "color: #f0b967;" \
                       "background-color: #8e0c02;" \
                       "border: 2px solid black;" \
                       "}"
        button_style1 = "QPushButton {" \
                       "font-family: Century Gothic;" \
                       "font-size: 13px;" \
                       "color: #f0b967;" \
                       "background-color: #8e0c02;" \
                       "border: 2px solid black;" \
                       "}"
        button1.setStyleSheet(button_style)
        button2.setStyleSheet(button_style)
        button3.setStyleSheet(button_style)
        button4.setStyleSheet(button_style)
        button5.setStyleSheet(button_style)
        button6.setStyleSheet(button_style1)

        # Расположение кнопок
        button1.setGeometry(40, 50, 200, 50)
        button2.setGeometry(40, 120, 200, 50)
        button3.setGeometry(40, 190, 200, 50)
        button4.setGeometry(40, 260, 200, 50)
        button5.setGeometry(40, 330, 200, 50)
        button6.setGeometry(40, 550, 130, 40)

        # Добавление фото
        self.photo_label = QLabel(self)
        self.photo_label.setGeometry(310, 5, 400, 400)
        pixmap = QPixmap("logo.jpg")
        self.photo_label.setPixmap(pixmap)
        self.photo_label.setScaledContents(True)

        #Добавление адреса
        text1 = QLabel("      *м.Текстильщики\n Волгоградский пр-к, д.45\n        +79191386200\n            9:00-22:00", self)
        text1.setStyleSheet("QLabel {"
                           "font-family: Century Gothic;"
                           "font-size: 14px;"
                           "color: #b67e4b;"
                           "}")
        text1.setGeometry(430, 460, 600, 150)

        # Добавление текста
        text = QLabel("С нас приятная атмосфера и вкусный попкорн.\n    С вас позитивные эмоции и хороший отзыв!",self)
        text.setStyleSheet("QLabel {"
                           "font-family: Century Gothic;"
                           "font-size: 18px;"
                           "color: #f0c159;"
                           "}")
        text.setGeometry(300, 340, 600, 150)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    cinema_app = CinemaApp()
    cinema_app.show()
    sys.exit(app.exec())