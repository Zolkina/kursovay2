import sys
from PyQt6.QtWidgets import QApplication, QMainWindow, QLabel, QPushButton
from PyQt6.QtGui import QAction, QColor, QPalette, QFont
from PyQt6.QtCore import Qt
import MainPage

class CafeMenu(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Скидки")
        self.setGeometry(500, 100, 800, 600)
        palette = QPalette()
        palette.setColor(QPalette.ColorRole.Window, QColor(141, 24, 27))
        self.setPalette(palette)

        self.initUI()

    def open_new_window(self):
        self.new_window = MainPage.CinemaApp()
        self.new_window.show()
        self.hide()

    def initUI(self):
        font = QFont("Century Gothic", 14)
        font2 = QFont("Century Gothic", 11)
        font1 = QFont("Century Gothic", 20)

        main_label = QLabel(self)
        main_label.setText("МЕНЮ")
        main_label.setFont(font1)
        main_label.setStyleSheet("color: #f0b967;")
        main_label.setGeometry(340, 50, 200, 30)

        label1 = QLabel("🍿 'Киноман' - $5", self)
        label1.setAlignment(Qt.AlignmentFlag.AlignLeft)
        label1.setFont(font)
        label1.setStyleSheet("color: #f0b967;")
        label1.setGeometry(60, 130, 200, 100)

        label11 = QLabel("- Попкорн соленый\n- Попкорн карамельный\n- Попкорн сырный\n- Попкорн ягодный", self)
        label11.setAlignment(Qt.AlignmentFlag.AlignLeft)
        label11.setFont(font2)
        label11.setStyleSheet("color: #f0b967;")
        label11.setGeometry(100, 160, 200, 100)

        label2 = QLabel("🍔 'Блокбастер' - $10", self)
        label2.setAlignment(Qt.AlignmentFlag.AlignLeft)
        label2.setFont(font)
        label2.setStyleSheet("color: #f0b967;")
        label2.setGeometry(60, 260, 210, 100)

        label22 = QLabel("- Чизбургер с картошкой фри\n- Чикенбургер с картошкой фри\n- Гамбургер с картошкой фри", self)
        label22.setAlignment(Qt.AlignmentFlag.AlignLeft)
        label22.setFont(font2)
        label22.setStyleSheet("color: #f0b967;")
        label22.setGeometry(100, 290, 400, 100)

        label3 = QLabel("🥗 'Здоровый фильм' - $8", self)
        label3.setAlignment(Qt.AlignmentFlag.AlignLeft)
        label3.setFont(font)
        label3.setStyleSheet("color: #f0b967;")
        label3.setGeometry(60, 390, 400, 100)

        label33 = QLabel("- Салат Цезарь с курицей\n- Салат Цезарь с креветками\n- Салат Греческий\n- Салат овощной", self)
        label33.setAlignment(Qt.AlignmentFlag.AlignLeft)
        label33.setFont(font2)
        label33.setStyleSheet("color: #f0b967;")
        label33.setGeometry(100, 420, 200, 100)

        label4 = QLabel("🌭 'Зрительское удовольствие' - $7", self)
        label4.setAlignment(Qt.AlignmentFlag.AlignLeft)
        label4.setFont(font)
        label4.setStyleSheet("color: #f0b967;")
        label4.setGeometry(440, 130, 400, 100)

        label44 = QLabel("- Хот-дог классический(кур/свин/гов)\n- Ход-до французский(кур/свин/гов)", self)
        label44.setAlignment(Qt.AlignmentFlag.AlignLeft)
        label44.setFont(font2)
        label44.setStyleSheet("color: #f0b967;")
        label44.setGeometry(480, 160, 300, 100)

        label5 = QLabel("☕ 'Киноклуб' - $3", self)
        label5.setAlignment(Qt.AlignmentFlag.AlignLeft)
        label5.setFont(font)
        label5.setStyleSheet("color: #f0b967;")
        label5.setGeometry(440, 260, 210, 100)

        label55 = QLabel("- Эспрессо\n- Амеликано(мал/сред/бол)\n- Капучино(мал/сред/бол)\n- Латте(мал/сред/бол)",self)
        label55.setAlignment(Qt.AlignmentFlag.AlignLeft)
        label55.setFont(font2)
        label55.setStyleSheet("color: #f0b967;")
        label55.setGeometry(480, 290, 400, 100)

        label6 = QLabel("🍹 'Фантастика' - $6", self)
        label6.setAlignment(Qt.AlignmentFlag.AlignLeft)
        label6.setFont(font)
        label6.setStyleSheet("color: #f0b967;")
        label6.setGeometry(440, 390, 400, 100)

        label66 = QLabel("-Кола(мал/сред/бол)\n- Кола без сахара(мал/сред/бол)\n- Фанта(мал/сред/бол)\n- Спрайт(мал/сред/бол)\n- Энергетик Adrenalin(0,5)",self)
        label66.setAlignment(Qt.AlignmentFlag.AlignLeft)
        label66.setFont(font2)
        label66.setStyleSheet("color: #f0b967;")
        label66.setGeometry(480, 420, 400, 100)

        back_button = QPushButton("Назад", self)
        button_style = "QPushButton {" \
                       "font-family: Century Gothic;" \
                       "font-size: 10px;" \
                       "color: #f0b967;" \
                       "background-color: #8e0c02;" \
                       "border: 2px solid black;" \
                       "}"
        back_button.setStyleSheet(button_style)
        back_button.clicked.connect(self.open_new_window)
        back_button.setGeometry(0, 555, 100, 35)

if __name__ == "__main__":
    app = QApplication([])
    window = CafeMenu()
    window.show()
    app.exec()