import sys
from PyQt6.QtWidgets import QMainWindow, QApplication, QLabel, QPushButton
from PyQt6.QtGui import QFont, QColor, QPalette, QPixmap
from PyQt6.QtCore import Qt
import MainPage

class Discount(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Скидки")
        self.setGeometry(500, 100, 800, 600)
        palette = QPalette()
        palette.setColor(QPalette.ColorRole.Window, QColor(141, 24, 27))
        self.setPalette(palette)

        self.initUI()

    def open_new_window(self):
        self.new_window = MainPage.CinemaApp()
        self.new_window.show()
        self.hide()

    def initUI(self):
        font = QFont("Century Gothic", 14)
        font1 =QFont("Century Gothic", 20)

        main_label = QLabel(self)
        main_label.setText("СКИДКИ")
        main_label.setFont(font1)
        main_label.setStyleSheet("color: #f0b967;")
        main_label.setGeometry(340, 50, 200, 30)

        label1 = QLabel(self)
        label1.setText(
            "ДЕТСКИЙ БИЛЕТ и ребенку, и одному взрослому")
        label1.setAlignment(Qt.AlignmentFlag.AlignCenter)
        label1.setFont(font)
        label1.setStyleSheet("color: #f0b967;")
        label1.setGeometry(130, 120, 500, 100)

        pixmap1 = QPixmap("11.png")
        label_image1 = QLabel(self)
        label_image1.setPixmap(pixmap1)
        label_image1.setGeometry(50, 130, 60, 60)

        label2 = QLabel(self)
        label2.setText(
            "ЛЕГЕНДАРНЫЕ ХОТ-ДОГИ\nДва 'Зрительских удовольствий' + 'Фантастика' 0.5")
        label2.setAlignment(Qt.AlignmentFlag.AlignLeft)
        label2.setFont(font)
        label2.setStyleSheet("color: #f0b967;")
        label2.setGeometry(147, 230, 500, 100)

        pixmap2 = QPixmap("12.png")
        label_image2 = QLabel(self)
        label_image2.setPixmap(pixmap2)
        label_image2.setGeometry(50, 220, 60, 60)

        label3 = QLabel(self)
        label3.setText(
            "СУПЕР ВТОРНИК\nСупер цена на все сеансы весь день")
        label3.setAlignment(Qt.AlignmentFlag.AlignLeft)
        label3.setFont(font)
        label3.setStyleSheet("color: #f0b967;")
        label3.setGeometry(147, 330, 500, 100)

        pixmap3 = QPixmap("13.png")
        label_image3 = QLabel(self)
        label_image3.setPixmap(pixmap3)
        label_image3.setGeometry(50, 320, 60, 60)

        label4 = QLabel(self)
        label4.setText(
            "ЗНАНИЕ - СИЛА\nСкидка 20% всем школьникам и студентам")
        label4.setAlignment(Qt.AlignmentFlag.AlignLeft)
        label4.setFont(font)
        label4.setStyleSheet("color: #f0b967;")
        label4.setGeometry(147, 435, 500, 100)

        pixmap4 = QPixmap("14.png")
        label_image4 = QLabel(self)
        label_image4.setPixmap(pixmap4)
        label_image4.setGeometry(50, 420, 70, 70)


        back_button = QPushButton("Назад", self)
        button_style = "QPushButton {" \
                       "font-family: Century Gothic;" \
                       "font-size: 10px;" \
                       "color: #f0b967;" \
                       "background-color: #8e0c02;" \
                       "border: 2px solid black;" \
                       "}"
        back_button.setStyleSheet(button_style)
        back_button.clicked.connect(self.open_new_window)
        back_button.setGeometry(0, 555, 100, 35)

if __name__ == "__main__":
    app = QApplication([])
    window = Discount()
    window.show()
    app.exec()